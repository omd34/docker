# FSTM-Projet
Plateforme de gestion d'événements (Projet académique):

Conception et réalisation d’une application web de gestion du
planning des manifestations dans une université et les
afficher dans un calendrier, Ainsi que la mise en place d’un
espace administrateur.

Outils et technologies : HTML5 - CSS3 - Boostrap - Javascript-
PHP/MySQL
